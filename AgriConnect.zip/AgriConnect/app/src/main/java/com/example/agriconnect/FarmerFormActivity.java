package com.example.agriconnect;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class FarmerFormActivity extends AppCompatActivity {

    private EditText etName, etContact, etCity;
    private Button btnSubmit;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farmer_form);

        etName = findViewById(R.id.etName);
        etContact = findViewById(R.id.etContact);
        etCity = findViewById(R.id.etCity);
        btnSubmit = findViewById(R.id.btnSubmit);
        progressBar = findViewById(R.id.progressBar);

        btnSubmit.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String contact = etContact.getText().toString().trim();
            String city = etCity.getText().toString().trim();

            if(name.isEmpty() || contact.isEmpty() || city.isEmpty()){
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            progressBar.setVisibility(ProgressBar.VISIBLE);

            Farmer farmer = new Farmer(name, contact, city);
            DummyDatabase.addFarmer(farmer);

            progressBar.setVisibility(ProgressBar.GONE);
            Toast.makeText(this, "Farmer Added Successfully", Toast.LENGTH_SHORT).show();

            startActivity(new Intent(FarmerFormActivity.this, FarmerDashboardActivity.class));
            finish();
        });
    }
}
