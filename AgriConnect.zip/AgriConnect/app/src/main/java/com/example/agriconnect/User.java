package com.example.agriconnect;

public class User {
    private String name;
    private String userType; // "Buyer" or "Farmer"

    public User(String name, String userType) {
        this.name = name;
        this.userType = userType;
    }

    public String getName() {
        return name;
    }

    public String getUserType() {
        return userType;
    }
}
