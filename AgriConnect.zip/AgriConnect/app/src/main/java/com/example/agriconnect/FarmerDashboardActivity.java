package com.example.agriconnect;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class FarmerDashboardActivity extends AppCompatActivity {

    CardView cropCard, weatherCard, marketCard, govtCard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farmer_dashboard);

        // CardView initialization
        cropCard = findViewById(R.id.crop_card);
        weatherCard = findViewById(R.id.weather_card);
        marketCard = findViewById(R.id.market_card);
        govtCard = findViewById(R.id.govt_card);

        // Card Click Listeners
        cropCard.setOnClickListener(v ->
                startActivity(new Intent(FarmerDashboardActivity.this, CropManagementActivity.class))
        );

        weatherCard.setOnClickListener(v ->
                startActivity(new Intent(FarmerDashboardActivity.this, WeatherActivity.class))
        );

        marketCard.setOnClickListener(v ->
                startActivity(new Intent(FarmerDashboardActivity.this, MarketPriceActivity.class))
        );

        govtCard.setOnClickListener(v ->
                startActivity(new Intent(FarmerDashboardActivity.this, GovtSchemeActivity.class))
        );
    }
}
