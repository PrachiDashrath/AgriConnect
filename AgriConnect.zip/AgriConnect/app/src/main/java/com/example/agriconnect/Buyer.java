package com.example.agriconnect;

public class Buyer {
    private String name;
    private String contact;
    private String city;

    public Buyer(String name, String contact, String city) {
        this.name = name;
        this.contact = contact;
        this.city = city;
    }

    public String getName() { return name; }
    public String getContact() { return contact; }
    public String getCity() { return city; }
}
