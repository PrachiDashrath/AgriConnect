package com.example.agriconnect;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MarketPriceActivity extends AppCompatActivity {

    RecyclerView rvMarketPrices;
    MarketPriceAdapter adapter;
    List<MarketPrice> marketList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_market_price);

        rvMarketPrices = findViewById(R.id.rvMarketPrices);
        rvMarketPrices.setLayoutManager(new LinearLayoutManager(this));

        // Sample data
        marketList = new ArrayList<>();
        marketList.add(new MarketPrice("Wheat", "₹2200/qtl"));
        marketList.add(new MarketPrice("Rice", "₹1800/qtl"));
        marketList.add(new MarketPrice("Sugarcane", "₹3000/qtl"));
        marketList.add(new MarketPrice("Tomato", "₹25/kg"));
        marketList.add(new MarketPrice("Potato", "₹15/kg"));

        adapter = new MarketPriceAdapter(this, marketList);
        rvMarketPrices.setAdapter(adapter);
    }
}
