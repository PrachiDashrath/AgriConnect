package com.example.agriconnect;

import java.util.ArrayList;
import java.util.List;

public class DummyDatabase {

    private static List<Buyer> buyers = new ArrayList<>();
    private static List<Farmer> farmers = new ArrayList<>();

    public static void addBuyer(Buyer buyer) {
        buyers.add(buyer);
    }

    public static void addFarmer(Farmer farmer) {
        farmers.add(farmer);
    }

    public static List<Buyer> getBuyers() {
        return buyers;
    }

    public static List<Farmer> getFarmers() {
        return farmers;
    }
}
