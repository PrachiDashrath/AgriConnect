package com.example.agriconnect;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MarketPriceAdapter extends RecyclerView.Adapter<MarketPriceAdapter.MarketViewHolder> {

    private Context context;
    private List<MarketPrice> marketList;

    public MarketPriceAdapter(Context context, List<MarketPrice> marketList) {
        this.context = context;
        this.marketList = marketList;
    }

    @NonNull
    @Override
    public MarketViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_market, parent, false);
        return new MarketViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MarketViewHolder holder, int position) {
        MarketPrice market = marketList.get(position);
        holder.tvCropName.setText(market.getCropName());
        holder.tvPrice.setText(market.getPrice());
    }

    @Override
    public int getItemCount() {
        return marketList.size();
    }

    static class MarketViewHolder extends RecyclerView.ViewHolder {
        TextView tvCropName, tvPrice;

        public MarketViewHolder(@NonNull View itemView) {
            super(itemView);
            tvCropName = itemView.findViewById(R.id.tvCropName);
            tvPrice = itemView.findViewById(R.id.tvPrice);
        }
    }
}
