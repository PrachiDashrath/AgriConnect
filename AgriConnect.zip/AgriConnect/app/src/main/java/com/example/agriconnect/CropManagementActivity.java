package com.example.agriconnect;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class CropManagementActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    CropAdapter adapter;
    List<Crop> cropList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_management);

        recyclerView = findViewById(R.id.recyclerViewCrops);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        loadSampleCrops();
    }

    private void loadSampleCrops() {
        cropList.add(new Crop("Wheat", "Planted", "Watering needed"));
        cropList.add(new Crop("Rice", "Harvesting", "Ready to harvest"));
        cropList.add(new Crop("Maize", "Growing", "Fertilize next week"));
        cropList.add(new Crop("Cotton", "Planted", "Monitor pests"));
        cropList.add(new Crop("Soybean", "Growing", "Irrigation required"));

        adapter = new CropAdapter(this, cropList);
        recyclerView.setAdapter(adapter);
    }
}
