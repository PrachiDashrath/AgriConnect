package com.example.agriconnect;

public class MarketPrice {
    private String cropName;
    private String price;

    public MarketPrice(String cropName, String price) {
        this.cropName = cropName;
        this.price = price;
    }

    public String getCropName() { return cropName; }
    public String getPrice() { return price; }
}
