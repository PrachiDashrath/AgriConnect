package com.example.agriconnect;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class UserTypeSelectionActivity extends AppCompatActivity {

    private Button btnBuyer, btnFarmer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_type_selection);

        btnBuyer = findViewById(R.id.btnBuyer);
        btnFarmer = findViewById(R.id.btnFarmer);

        btnBuyer.setOnClickListener(v -> {
            startActivity(new Intent(UserTypeSelectionActivity.this, BuyerFormActivity.class));
        });

        btnFarmer.setOnClickListener(v -> {
            startActivity(new Intent(UserTypeSelectionActivity.this, FarmerFormActivity.class));
        });
    }
}
