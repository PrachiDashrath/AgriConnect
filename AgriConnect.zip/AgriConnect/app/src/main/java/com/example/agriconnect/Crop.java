package com.example.agriconnect;

public class Crop {
    private String name;
    private String status;
    private String nextAction;

    public Crop(String name, String status, String nextAction) {
        this.name = name;
        this.status = status;
        this.nextAction = nextAction;
    }

    public String getName() {
        return name;
    }

    public String getStatus() {
        return status;
    }

    public String getNextAction() {
        return nextAction;
    }
}
