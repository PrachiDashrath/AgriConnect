package com.example.agriconnect;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.card.MaterialCardView;

public class BuyerDashboardActivity extends AppCompatActivity {

    private MaterialCardView cardFruits, cardVegetables, cardGrains, cardDairy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buyer_dashboard);

        // Linking XML cards
        cardFruits = findViewById(R.id.cardFruits);
        cardVegetables = findViewById(R.id.cardVegetables);
        cardGrains = findViewById(R.id.cardGrains);
        cardDairy = findViewById(R.id.cardDairy);

        // Fruits Activity
        cardFruits.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BuyerDashboardActivity.this, FruitsActivity.class);
                startActivity(intent);
            }
        });

        // Vegetables Activity
        cardVegetables.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BuyerDashboardActivity.this, VegetablesActivity.class);
                startActivity(intent);
            }
        });

        // Grains Activity
        cardGrains.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BuyerDashboardActivity.this, GrainsActivity.class);
                startActivity(intent);
            }
        });

        // Dairy Activity
        cardDairy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BuyerDashboardActivity.this, DairyActivity.class);
                startActivity(intent);
            }
        });
    }
}
